package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private TextField addressField;

    @FXML
    private TextField contactField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField nameField;
    @FXML
    private TableView<Person> PersonTableView;
    @FXML
    private TableColumn<Person, String> nameCol;
    @FXML
    private TableColumn<Person, String> addressCol;
    @FXML
    private TableColumn<Person, String> contactCol;
    @FXML
    private TableColumn<Person, String> emailCol;

    private ObservableList<Person> initialData(){

       return FXCollections.observableArrayList();
    }

    @FXML
    private void handleSaveAction (ActionEvent event) {

        Person newPerson = new Person(nameField.getText(), contactField.getText(), emailField.getText(), addressField.getText());

        PersonTableView.getItems().add(newPerson);

        nameField.clear();
        emailField.clear();
        contactField.clear();
        addressField.clear();

//        String name = nameField.getText();
//        String email = emailField.getText();
//        String contact = contactField.getText();
//        String address = addressField.getText();
//
//
//
//        System.out.println("Name: " + name + "\n" + "Email: " + email + "\n" + "Contact: " + contact + "\n" + "Address: " + address);

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        nameCol.setCellValueFactory(new PropertyValueFactory<Person, String>("name"));
        addressCol.setCellValueFactory(new PropertyValueFactory<Person, String>("address"));
        contactCol.setCellValueFactory(new PropertyValueFactory<Person, String>("contact"));
        emailCol.setCellValueFactory(new PropertyValueFactory<Person, String>("email"));
        PersonTableView.setItems(initialData());
    }
}

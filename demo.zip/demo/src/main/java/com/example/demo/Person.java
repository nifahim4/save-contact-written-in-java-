package com.example.demo;

public class Person {
    private String name;
    private String address;
    private String Contact;
    private String email;

    public Person() {
    }

    public Person(String name, String address, String contact, String email) {
        this.name = name;
        this.address = address;
        Contact = contact;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getContact() {
        return Contact;
    }

    public String getEmail() {
        return email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setContact(String contact) {
        Contact = contact;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
